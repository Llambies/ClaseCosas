# -*- coding: utf-8 -*-
from . import tarea_quick_add_wizard
