# -*- coding: utf-8 -*-
from . import tarea
from . import sale_order
