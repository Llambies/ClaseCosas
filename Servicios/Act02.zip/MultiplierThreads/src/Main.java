public class Main {
    public static void main(String[] args) {
        Multiplicador multiplicador1 = new Multiplicador(1);
        Multiplicador multiplicador2 = new Multiplicador(2);
        Multiplicador multiplicador3 = new Multiplicador(3);
        Multiplicador multiplicador4 = new Multiplicador(4);
        Multiplicador multiplicador5 = new Multiplicador(5);
        Multiplicador multiplicador6 = new Multiplicador(6);
        Multiplicador multiplicador7 = new Multiplicador(7);
        Multiplicador multiplicador8 = new Multiplicador(8);
        Multiplicador multiplicador9 = new Multiplicador(9);
        Multiplicador multiplicador10 = new Multiplicador(10);


        multiplicador1.start();
        multiplicador2.start();
        multiplicador3.start();
        multiplicador4.start();
        multiplicador5.start();
        multiplicador6.start();
        multiplicador7.start();
        multiplicador8.start();
        multiplicador9.start();
        multiplicador10.start();


    }
}